package com.cabbookdriver.cabbookdriver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabbookdriverApplicationTests {

	@Test
	void contextLoads() {
	}

}
