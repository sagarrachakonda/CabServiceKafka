package com.cabbookuser.cabbookuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabbookuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(CabbookuserApplication.class, args);
	}

}
